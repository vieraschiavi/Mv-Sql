# © 2026 Martín Viera. Todos los derechos reservados.

"""
exportar.py — MV SQL NLP
==================================================================
Exportación de resultados a Excel (.xlsx), CSV, PDF y HTML.
Todos devuelven bytes listos para descargar desde la interfaz.
==================================================================
"""

import io
from datetime import datetime


def a_csv(df):
    return df.to_csv(index=False).encode("utf-8-sig")  # BOM: Excel abre acentos bien


#: Filas de datos que entran en una hoja de Excel: el formato admite
#: 1.048.576 filas y acá se usan dos para el título y el encabezado.
FILAS_POR_HOJA_EXCEL = 1_048_576 - 2


def a_excel(df, titulo="Consulta MV SQL NLP", sql=""):
    """Excel con formato: encabezado con estilo, autofiltro y hoja de metadatos.

    Lleva TODAS las filas del resultado. Excel no admite más de 1.048.576
    filas por hoja; si el resultado pasa de eso (sin tope de filas puede
    pasar) se reparte en «Resultado», «Resultado_2», ... en vez de romper la
    exportación o cortar callado. La hoja «Info» dice cuántas filas y hojas.
    """
    buf = io.BytesIO()
    import pandas as pd
    from openpyxl.styles import Font, PatternFill
    tramos = [df.iloc[i:i + FILAS_POR_HOJA_EXCEL]
              for i in range(0, len(df), FILAS_POR_HOJA_EXCEL)] or [df]
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for n, parte in enumerate(tramos, start=1):
            hoja = "Resultado" if n == 1 else f"Resultado_{n}"
            parte.to_excel(writer, sheet_name=hoja, index=False, startrow=1)
            ws = writer.sheets[hoja]
            ws["A1"] = titulo if len(tramos) == 1 else f"{titulo} ({n}/{len(tramos)})"
            ws["A1"].font = Font(bold=True, size=13, color="1E3A8A")
            header_fill = PatternFill("solid", fgColor="1E3A8A")
            for col_idx in range(1, len(parte.columns) + 1):
                c = ws.cell(row=2, column=col_idx)
                c.font = Font(bold=True, color="FFFFFF")
                c.fill = header_fill
            # ancho de columnas. El max() incluye el largo del encabezado
            # como semilla: sin eso, con un DataFrame de 0 filas el generador
            # queda vacío y `max()` sin argumentos tira TypeError — cualquier
            # consulta válida que devuelva 0 filas ("ventas de un mes
            # futuro") tumbaba la exportación entera con un traceback.
            for i, col in enumerate(parte.columns, start=1):
                ancho = max([len(str(col))] + [len(str(v)) for v in parte[col].head(200)]) + 2
                ws.column_dimensions[ws.cell(row=2, column=i).column_letter].width = min(40, ancho)
            if len(parte):
                ws.auto_filter.ref = (f"A2:{ws.cell(row=2, column=len(parte.columns)).column_letter}"
                                      f"{len(parte) + 2}")

        meta = pd.DataFrame({
            "Campo": ["Generado por", "Fecha", "Filas", "Hojas de resultado", "SQL"],
            "Valor": ["MV SQL NLP", datetime.now().strftime("%Y-%m-%d %H:%M"),
                      len(df), len(tramos), sql[:1000]],
        })
        meta.to_excel(writer, sheet_name="Info", index=False)
    return buf.getvalue()


def a_pdf(df, titulo="Consulta MV SQL NLP", pregunta="", sql="",
          explicacion="", max_filas=200):
    """PDF profesional con tabla, pregunta y explicación (reportlab)."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                    Paragraph, Spacer)

    buf = io.BytesIO()
    pagina = landscape(A4) if len(df.columns) > 6 else A4
    doc = SimpleDocTemplate(buf, pagesize=pagina,
                            leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=15 * mm, bottomMargin=15 * mm)
    estilos = getSampleStyleSheet()
    azul = colors.HexColor("#1e3a8a")
    h1 = ParagraphStyle("h1", parent=estilos["Title"], textColor=azul, fontSize=16)
    normal = estilos["BodyText"]

    partes = [Paragraph(titulo, h1)]
    if pregunta:
        partes += [Paragraph(f"<b>Pregunta:</b> {pregunta}", normal), Spacer(1, 4)]
    if explicacion:
        partes += [Paragraph(f"<b>Análisis:</b> {explicacion}", normal), Spacer(1, 4)]
    partes.append(Paragraph(
        f"<font size=8 color='#64748b'>Generado por MV SQL NLP · "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M')} · {len(df)} filas"
        f"{' (mostrando ' + str(max_filas) + ')' if len(df) > max_filas else ''}</font>",
        normal))
    partes.append(Spacer(1, 8))

    datos = [list(df.columns)] + df.head(max_filas).astype(str).values.tolist()
    tabla = Table(datos, repeatRows=1)
    tabla.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), azul),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    partes.append(tabla)

    if sql:
        partes += [Spacer(1, 10),
                   Paragraph("<b>SQL ejecutado:</b>", normal),
                   Paragraph(f"<font face='Courier' size=7>{sql.replace(chr(10), '<br/>')}</font>", normal)]

    doc.build(partes)
    return buf.getvalue()


def a_html(df, titulo="Consulta MV SQL NLP"):
    tabla = df.to_html(index=False, border=0)
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{titulo}</title>
<style>
body{{font-family:system-ui,Segoe UI,Arial;margin:2rem;color:#0f172a}}
h1{{color:#1e3a8a}} table{{border-collapse:collapse;width:100%}}
th{{background:#1e3a8a;color:#fff;padding:.5rem;text-align:left}}
td{{padding:.4rem .5rem;border-bottom:1px solid #e2e8f0}}
tr:nth-child(even) td{{background:#f8fafc}}
</style></head><body><h1>{titulo}</h1>{tabla}
<p style="color:#64748b;font-size:.8rem">Generado por MV SQL NLP</p></body></html>"""
    return html.encode("utf-8")


def a_json(df, orient="records", indent=2):
    """JSON del resultado, listo para consumir desde otro sistema.

    `orient="records"` produce una lista de objetos ({columna: valor}),
    que es lo que espera casi cualquier API o script. Las fechas salen
    en formato ISO para que no haya ambigüedad entre locales.
    """
    return df.to_json(orient=orient, indent=indent, force_ascii=False,
                      date_format="iso").encode("utf-8")
