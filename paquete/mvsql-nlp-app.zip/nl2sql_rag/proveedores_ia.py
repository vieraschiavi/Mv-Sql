# © 2026 Martín Viera. Todos los derechos reservados.

"""
proveedores_ia.py — MV SQL NLP
==================================================================
Capa unificada de proveedores de IA. El cliente elige QUÉ IA usa:
Anthropic (Claude), OpenAI (GPT), Google (Gemini), Groq, Mistral,
DeepSeek, xAI (Grok), Ollama (local, gratis) o cualquier endpoint
compatible con la API de OpenAI.

Todo por REST puro (requests) — sin SDKs, sin dependencias pesadas.
==================================================================
"""

import json
import os
import requests

TIMEOUT = 90

RUTA_LICENCIA = os.path.join(os.path.dirname(__file__), "licencia_mvsql.json")


def cargar_licencia_creditos():
    """Si el zip descargado incluye créditos embebidos, devuelve la licencia."""
    if not os.path.exists(RUTA_LICENCIA):
        return None
    try:
        with open(RUTA_LICENCIA, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


# Catálogo de proveedores soportados "de fábrica".
# El usuario puede además agregar un proveedor "custom" (OpenAI-compatible).
PROVEEDORES = {
    "mvsql_creditos": {
        "nombre": "MV SQL Créditos (sin API key)",
        "modelos": [],
        "modelo_default": "",
        "necesita_key": False,
        "url_keys": "https://mvsqlnlp.com/#precios",
    },
    "anthropic": {
        "nombre": "Anthropic (Claude)",
        "modelos": ["claude-sonnet-5", "claude-haiku-4-5-20251001", "claude-opus-4-8"],
        "modelo_default": "claude-haiku-4-5-20251001",
        "necesita_key": True,
        "url_keys": "https://console.anthropic.com/",
    },
    "openai": {
        "nombre": "OpenAI (GPT)",
        "modelos": ["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1"],
        "modelo_default": "gpt-4o-mini",
        "necesita_key": True,
        "url_keys": "https://platform.openai.com/api-keys",
    },
    "azure": {
        "nombre": "Microsoft Copilot (Azure OpenAI)",
        "modelos": [],
        "modelo_default": "",
        "necesita_key": True,
        "url_keys": "https://portal.azure.com/#create/Microsoft.CognitiveServicesOpenAI",
    },
    "gemini": {
        "nombre": "Google (Gemini)",
        "modelos": ["gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro"],
        "modelo_default": "gemini-2.0-flash",
        "necesita_key": True,
        "url_keys": "https://aistudio.google.com/apikey",
    },
    "groq": {
        "nombre": "Groq (Llama, ultra rápido)",
        "modelos": ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
        "modelo_default": "llama-3.3-70b-versatile",
        "necesita_key": True,
        "url_keys": "https://console.groq.com/keys",
    },
    "mistral": {
        "nombre": "Mistral AI",
        "modelos": ["mistral-small-latest", "mistral-large-latest", "codestral-latest"],
        "modelo_default": "mistral-small-latest",
        "necesita_key": True,
        "url_keys": "https://console.mistral.ai/",
    },
    "deepseek": {
        "nombre": "DeepSeek",
        "modelos": ["deepseek-chat", "deepseek-reasoner"],
        "modelo_default": "deepseek-chat",
        "necesita_key": True,
        "url_keys": "https://platform.deepseek.com/",
    },
    "xai": {
        "nombre": "xAI (Grok)",
        "modelos": ["grok-3-mini", "grok-3"],
        "modelo_default": "grok-3-mini",
        "necesita_key": True,
        "url_keys": "https://console.x.ai/",
    },
    "ollama": {
        "nombre": "Ollama (local, sin costo)",
        "modelos": ["llama3.1", "qwen2.5-coder", "mistral", "sqlcoder"],
        "modelo_default": "llama3.1",
        "necesita_key": False,
        "url_keys": "https://ollama.com/download",
    },
    "custom": {
        "nombre": "Otro (endpoint OpenAI-compatible)",
        "modelos": [],
        "modelo_default": "",
        "necesita_key": True,
        "url_keys": "",
    },
}

# Endpoints OpenAI-compatibles (chat/completions)
_BASES_OPENAI_COMPAT = {
    "openai": "https://api.openai.com/v1",
    "groq": "https://api.groq.com/openai/v1",
    "mistral": "https://api.mistral.ai/v1",
    "deepseek": "https://api.deepseek.com/v1",
    "xai": "https://api.x.ai/v1",
}


class ErrorProveedor(RuntimeError):
    pass


def _post(url, headers, payload):
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
    except requests.exceptions.ConnectionError as e:
        raise ErrorProveedor(f"No se pudo conectar al proveedor ({url}): {e}")
    except requests.exceptions.Timeout:
        raise ErrorProveedor("El proveedor de IA tardó demasiado en responder (timeout).")
    if r.status_code == 401:
        raise ErrorProveedor("API key inválida o vencida (401). Verificá la clave en Configuración.")
    if r.status_code == 429:
        raise ErrorProveedor("Límite de uso del proveedor alcanzado (429). Esperá unos segundos o cambiá de proveedor.")
    if r.status_code >= 400:
        raise ErrorProveedor(f"Error del proveedor ({r.status_code}): {r.text[:300]}")
    return r.json()


def _get(url, headers=None, params=None):
    try:
        r = requests.get(url, headers=headers or {}, params=params, timeout=TIMEOUT)
    except requests.exceptions.ConnectionError as e:
        raise ErrorProveedor(f"No se pudo conectar al proveedor ({url}): {e}")
    except requests.exceptions.Timeout:
        raise ErrorProveedor("El proveedor de IA tardó demasiado en responder (timeout).")
    if r.status_code == 401:
        raise ErrorProveedor("API key inválida o vencida (401). Verificá la clave en Configuración.")
    if r.status_code == 429:
        raise ErrorProveedor("Límite de uso del proveedor alcanzado (429). Esperá unos segundos o cambiá de proveedor.")
    if r.status_code >= 400:
        raise ErrorProveedor(f"Error del proveedor ({r.status_code}): {r.text[:300]}")
    return r.json()


# ── Listado de modelos EN VIVO ──────────────────────────────────────
#
# PROVEEDORES["...]["modelos"] es una lista fija que se desactualiza en
# cuanto el proveedor saca un modelo nuevo — y eso pasa seguido: hay que
# tocar código y republicar para que el cliente pueda elegir un modelo
# que salió la semana pasada. Estas funciones consultan el catálogo real
# por API, con la API key que el cliente ya puso, para que la lista de
# modelos esté al día sin depender de un release nuestro.

# Ids que aparecen en el listado de modelos pero no sirven para chat
# (embeddings, audio, moderación, imagen): mostrarlos solo confundiría
# la elección. No es una lista exhaustiva a propósito — ante la duda se
# incluye, porque un modelo de más se descarta con la vista y uno de
# menos ni se sabe que faltó.
_NO_CHAT = ("embed", "whisper", "tts", "dall-e", "moderation", "clip",
            "davinci-002", "babbage-002", "text-moderation")


def _es_modelo_chat(id_modelo):
    bajo = id_modelo.lower()
    return not any(x in bajo for x in _NO_CHAT)


def _modelos_anthropic(api_key):
    headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01"}
    data = _get("https://api.anthropic.com/v1/models", headers, params={"limit": 100})
    items = [m for m in data.get("data", []) if m.get("id")]
    items.sort(key=lambda m: m.get("created_at", ""), reverse=True)
    return [m["id"] for m in items]


def _modelos_openai_compat(base, api_key):
    headers = {"Authorization": f"Bearer {api_key}"}
    data = _get(f"{base.rstrip('/')}/models", headers)
    items = [m for m in data.get("data", []) if m.get("id") and _es_modelo_chat(m["id"])]
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return [m["id"] for m in items]


def _modelos_gemini(api_key):
    data = _get("https://generativelanguage.googleapis.com/v1beta/models",
                params={"key": api_key, "pageSize": 1000})
    salida = []
    for m in data.get("models", []):
        # Solo los que de verdad sirven para esto: Gemini también lista
        # modelos de embeddings y de generación de imagen bajo el mismo
        # endpoint, que no aceptan un system prompt + mensaje de chat.
        if "generateContent" not in (m.get("supportedGenerationMethods") or []):
            continue
        nombre = (m.get("name") or "").split("/")[-1]
        if nombre:
            salida.append(nombre)
    return salida


def _modelos_ollama(base_url):
    base = (base_url or "http://localhost:11434").rstrip("/")
    data = _get(f"{base}/api/tags")
    items = [m for m in data.get("models", []) if m.get("name") or m.get("model")]
    items.sort(key=lambda m: m.get("modified_at", ""), reverse=True)
    return [m.get("name") or m.get("model") for m in items]


def listar_modelos(proveedor, api_key=None, base_url=None):
    """
    Trae del proveedor la lista real de modelos disponibles para esa API
    key, más nuevos primero cuando el proveedor informa la fecha.

    No lanza para "no hay modelos nuevos" (eso no es un error, es una
    lista vacía) — SÍ lanza ErrorProveedor para lo que impide seguir:
    proveedor sin listado por API, sin key, o cualquier falla de red que
    ya maneja _get() (401, 429, timeout, etc).
    """
    proveedor = (proveedor or "").lower()
    info = PROVEEDORES.get(proveedor)
    if not info:
        raise ErrorProveedor(f"Proveedor desconocido: {proveedor}")

    if proveedor == "mvsql_creditos":
        raise ErrorProveedor("MV SQL Créditos no tiene modelos para elegir: es un servicio ya configurado.")
    if proveedor == "azure":
        # El listado real de deployments de Azure OpenAI se hace con
        # credenciales de gestión de Azure (Azure AD), no con la api-key
        # del recurso — no hay una API simple y equivalente que consultar
        # acá. El nombre del deployment se sigue escribiendo a mano.
        raise ErrorProveedor("Azure OpenAI no expone sus modelos por esta vía: escribí el nombre del deployment a mano.")

    if info["necesita_key"] and not api_key:
        raise ErrorProveedor("Falta la API key.")

    if proveedor == "anthropic":
        return _modelos_anthropic(api_key)
    if proveedor == "gemini":
        return _modelos_gemini(api_key)
    if proveedor == "ollama":
        return _modelos_ollama(base_url)

    base = base_url or _BASES_OPENAI_COMPAT.get(proveedor)
    if not base:
        raise ErrorProveedor(f"Proveedor '{proveedor}' necesita una Base URL para listar modelos.")
    return _modelos_openai_compat(base, api_key)


def completar(proveedor, api_key, system, user, modelo=None, max_tokens=1500,
              base_url=None, temperatura=0.0):
    """
    Punto único de entrada: manda (system, user) al proveedor elegido
    y devuelve el texto de respuesta.

    proveedor: clave de PROVEEDORES ('anthropic', 'openai', 'gemini', ...)
    base_url:  para 'custom' (endpoint OpenAI-compatible) u 'ollama' remoto.
    """
    proveedor = (proveedor or "anthropic").lower()

    if proveedor == "mvsql_creditos":
        licencia = cargar_licencia_creditos()
        if not licencia:
            raise ErrorProveedor(
                "No se encontró licencia_mvsql.json. Este proveedor solo funciona en el "
                "zip descargado con el plan de créditos embebidos — comprá uno en "
                "mvsqlnlp.com o elegí otro proveedor y pon tu propia API key.")
        # Una licencia de plan 'own_ai' (API key propia) no trae proxy_url ni
        # token: sin este chequeo, elegir "MV SQL Créditos" con esa licencia
        # —y es la primera opción del selector— tiraba un KeyError crudo en
        # vez de un mensaje que diga qué hacer.
        if not licencia.get("proxy_url") or not licencia.get("token"):
            raise ErrorProveedor(
                "Tu licencia no incluye créditos de IA (es un plan con tu propia API key). "
                "Elegí tu proveedor en la barra lateral y poné tu clave, o comprá un "
                "paquete de créditos en mvsqlnlp.com.")
        data = _post(
            licencia["proxy_url"], {"content-type": "application/json"},
            {"token": licencia["token"], "system": system, "user": user,
             "max_tokens": max_tokens},
        )
        if "error" in data:
            raise ErrorProveedor(data["error"])
        return data.get("text", "")

    if proveedor == "anthropic":
        payload = {"model": modelo or PROVEEDORES["anthropic"]["modelo_default"],
                   "max_tokens": max_tokens, "temperature": temperatura,
                   "system": system,
                   "messages": [{"role": "user", "content": user}]}
        headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}
        try:
            data = _post("https://api.anthropic.com/v1/messages", headers, payload)
        except ErrorProveedor as e:
            # Los modelos más nuevos (ej. claude-opus-4-8) rechazan
            # `temperature` con 400 "temperature is deprecated for this
            # model" — reintentar sin el parámetro.
            if "temperature" in str(e) and "temperature" in payload:
                payload.pop("temperature")
                data = _post("https://api.anthropic.com/v1/messages", headers, payload)
            else:
                raise
        return "".join(b.get("text", "") for b in data.get("content", []))

    if proveedor == "azure":
        # Azure OpenAI (el backend de Microsoft Copilot para empresas).
        # base_url: https://<recurso>.openai.azure.com — modelo = nombre del deployment.
        if not base_url:
            raise ErrorProveedor(
                "Azure OpenAI necesita la URL del recurso (ej: https://mirecurso.openai.azure.com) "
                "en el campo Base URL, y el nombre del deployment en el campo Modelo.")
        deployment = modelo or "gpt-4o-mini"
        url_az = (f"{base_url.rstrip('/')}/openai/deployments/{deployment}"
                  "/chat/completions?api-version=2024-06-01")
        headers_az = {"api-key": api_key, "content-type": "application/json"}
        payload_az = {"max_tokens": max_tokens, "temperature": temperatura,
                      "messages": [{"role": "system", "content": system},
                                   {"role": "user", "content": user}]}
        try:
            data = _post(url_az, headers_az, payload_az)
        except ErrorProveedor as e:
            msg = str(e)
            cambiado = False
            if "temperature" in msg and "temperature" in payload_az:
                payload_az.pop("temperature")
                cambiado = True
            if "max_completion_tokens" in msg and "max_tokens" in payload_az:
                payload_az["max_completion_tokens"] = payload_az.pop("max_tokens")
                cambiado = True
            if not cambiado:
                raise
            data = _post(url_az, headers_az, payload_az)
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            raise ErrorProveedor(f"Respuesta inesperada de Azure OpenAI: {json.dumps(data)[:300]}")

    if proveedor == "gemini":
        m = modelo or PROVEEDORES["gemini"]["modelo_default"]
        data = _post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={api_key}",
            {"content-type": "application/json"},
            {"system_instruction": {"parts": [{"text": system}]},
             "contents": [{"role": "user", "parts": [{"text": user}]}],
             "generationConfig": {"maxOutputTokens": max_tokens, "temperature": temperatura}},
        )
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            raise ErrorProveedor(f"Respuesta inesperada de Gemini: {json.dumps(data)[:300]}")

    if proveedor == "ollama":
        base = (base_url or "http://localhost:11434").rstrip("/")
        data = _post(
            f"{base}/api/chat", {"content-type": "application/json"},
            {"model": modelo or PROVEEDORES["ollama"]["modelo_default"],
             "stream": False, "options": {"temperature": temperatura},
             "messages": [{"role": "system", "content": system},
                          {"role": "user", "content": user}]},
        )
        return data.get("message", {}).get("content", "")

    # Resto: API OpenAI-compatible (openai, groq, mistral, deepseek, xai, custom)
    base = base_url or _BASES_OPENAI_COMPAT.get(proveedor)
    if not base:
        raise ErrorProveedor(f"Proveedor '{proveedor}' requiere base_url (endpoint OpenAI-compatible).")
    info = PROVEEDORES.get(proveedor, {})
    url = f"{base.rstrip('/')}/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "content-type": "application/json"}
    payload = {"model": modelo or info.get("modelo_default") or "gpt-4o-mini",
               "max_tokens": max_tokens, "temperature": temperatura,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": user}]}
    try:
        data = _post(url, headers, payload)
    except ErrorProveedor as e:
        # Modelos nuevos de OpenAI rechazan `temperature` distinto del
        # default y/o piden `max_completion_tokens` en vez de `max_tokens`
        # — adaptar el payload según el mensaje y reintentar una vez.
        msg = str(e)
        cambiado = False
        if "temperature" in msg and "temperature" in payload:
            payload.pop("temperature")
            cambiado = True
        if "max_completion_tokens" in msg and "max_tokens" in payload:
            payload["max_completion_tokens"] = payload.pop("max_tokens")
            cambiado = True
        if not cambiado:
            raise
        data = _post(url, headers, payload)
    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise ErrorProveedor(f"Respuesta inesperada del proveedor: {json.dumps(data)[:300]}")


def probar_conexion(proveedor, api_key, modelo=None, base_url=None):
    """Prueba rápida de credenciales. Devuelve (ok, mensaje)."""
    try:
        txt = completar(proveedor, api_key, "Respondé solo con la palabra OK.",
                        "ping", modelo=modelo, max_tokens=10, base_url=base_url)
        return True, f"Conexión OK — respuesta: {txt.strip()[:40]}"
    except Exception as e:
        return False, str(e)
