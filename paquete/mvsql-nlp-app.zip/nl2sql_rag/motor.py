# © 2026 Martín Viera. Todos los derechos reservados.

"""
motor.py — MV SQL NLP
==================================================================
Motor NL2SQL multi-proveedor con RAG sobre el catálogo del esquema.

Flujo:
  pregunta (lenguaje natural, ES/EN/PT)
    -> RAG: recuperar tablas relevantes (TF-IDF local, nada sale de tu red)
    -> IA (a elección del cliente): genera SQL optimizado con CTE
    -> Validador: cada tabla/columna debe existir en el catálogo
    -> Intervalo de confianza: qué tan segura es la traducción
    -> Ejecución segura (solo SELECT, tope de filas automático)
    -> Explicación en lenguaje natural del resultado
==================================================================
"""

import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from catalogo import catalogo_a_fichas
from proveedores_ia import completar


# ──────────────────────────────────────────────────────────────
# 1) RETRIEVAL (RAG) — TF-IDF local sobre las fichas del esquema
# ──────────────────────────────────────────────────────────────
class RecuperadorEsquema:
    def __init__(self, fichas):
        self.fichas = fichas
        self.textos = [f["texto"] for f in fichas]
        self.vec = TfidfVectorizer(lowercase=True, ngram_range=(1, 2),
                                   token_pattern=r"[a-zA-Zàáâãéêíóôõúüçñ_]+")
        self.matriz = self.vec.fit_transform(self.textos)

    def recuperar(self, pregunta, k=4):
        """Devuelve (fichas_top_k, similitudes_top_k)."""
        q = self.vec.transform([pregunta])
        sims = cosine_similarity(q, self.matriz)[0]
        idx = sims.argsort()[::-1][:max(k, 3)]
        return [self.fichas[i] for i in idx], [float(sims[i]) for i in idx]


# ──────────────────────────────────────────────────────────────
# 2) GENERACIÓN SQL (multi-proveedor, con CTE y autoevaluación)
# ──────────────────────────────────────────────────────────────
# Los prompts de sistema (SYSTEM_SQL/SYSTEM_EXPLICAR/SYSTEM_PROCEDURE) NO
# viven acá como constantes de módulo a propósito: eran importables con
# `import motor; motor.SYSTEM_SQL` — legibles con dos líneas de Python
# aunque este archivo esté compilado con Cython (tools/build_cython.py).
# Compilado o no, un atributo público de módulo siempre es introspectable.
# Viven como variables locales dentro de los métodos que los usan
# (MotorMVSQL.responder / .generar_stored_procedure): sin un nombre
# público que apunte a ellos, extraerlos requiere desensamblar la
# extensión compilada o interceptar la llamada real a la IA, no un
# `dir(motor)`.


def _parsear_respuesta_sql(texto):
    """Extrae (sql, confianza_llm, supuestos) del formato pedido al modelo."""
    texto = texto.strip()
    # limpiar fences por si el modelo desobedece
    texto = re.sub(r"```sql|```", "", texto, flags=re.IGNORECASE).strip()

    conf = None
    m = re.search(r"CONFIANZA:\s*(\d{1,3})", texto)
    if m:
        conf = max(0, min(100, int(m.group(1))))

    supuestos = ""
    m = re.search(r"SUPUESTOS:\s*(.+)", texto)
    if m:
        supuestos = m.group(1).strip()

    sql = texto
    m = re.search(r"SQL:\s*(.*?)(?:CONFIANZA:|$)", texto, flags=re.DOTALL)
    if m:
        sql = m.group(1).strip()
    else:
        # el modelo devolvió solo el SQL
        sql = re.split(r"CONFIANZA:", texto)[0].strip()
    return sql, conf, supuestos


# ──────────────────────────────────────────────────────────────
# 3) VALIDADOR contra el catálogo
# ──────────────────────────────────────────────────────────────
PALABRAS_PROHIBIDAS = ["insert ", "update ", "delete ", "drop ", "alter ",
                       "truncate ", "create ", "exec ", "execute ", "merge ",
                       "grant ", "revoke ", "xp_", "sp_executesql"]

PALABRAS_SQL = {
    # keywords/aliases que el extractor de "tablas" puede confundir
    "select", "where", "group", "order", "having", "limit", "offset", "union",
    "unnest", "generate_series", "dual", "values", "lateral",
}


def validar_sql(sql, catalogo, ctes=None):
    """Devuelve (es_valido, problemas, advertencias)."""
    problemas, advertencias = [], []
    s = sql.lower()

    for p in PALABRAS_PROHIBIDAS:
        if p in s:
            problemas.append(f"Operación no permitida: '{p.strip()}' — MV SQL NLP es solo lectura.")
    inicio = s.lstrip()[:8]
    if not (inicio.startswith("select") or inicio.startswith("with")):
        problemas.append("La consulta debe empezar con SELECT o WITH (CTE).")

    # nombres de CTE definidos en la consulta cuentan como tablas válidas
    nombres_cte = set(re.findall(r"(?:with|,)\s*([a-zA-Z_][a-zA-Z0-9_]*)\s+as\s*\(", s))

    tablas_catalogo = {t.lower() for t in catalogo["tablas"].keys()}
    tablas_en_sql = set(re.findall(r"(?:from|join)\s+\[?([a-zA-Z_][a-zA-Z0-9_.]*)\]?", s))
    for t in tablas_en_sql:
        t_simple = t.split(".")[-1]
        if t_simple in PALABRAS_SQL or t_simple in nombres_cte:
            continue
        if t_simple not in tablas_catalogo:
            problemas.append(f"Tabla inexistente en el catálogo: '{t}'")

    columnas_catalogo = set()
    for info in catalogo["tablas"].values():
        for c in info["columnas"]:
            columnas_catalogo.add(c["columna"].lower())

    posibles = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*\.([a-zA-Z_][a-zA-Z0-9_]*)", s)
    for col in set(posibles):
        if col not in columnas_catalogo and col != "*" and col not in PALABRAS_SQL:
            advertencias.append(f"Columna no reconocida en el catálogo: '{col}' (puede ser alias de CTE)")

    return len(problemas) == 0, problemas, advertencias


# ──────────────────────────────────────────────────────────────
# 4) INTERVALO DE CONFIANZA
# ──────────────────────────────────────────────────────────────
def calcular_confianza(conf_llm, sim_rag, es_valido, n_advertencias, usa_cte,
                       cobertura=None, ejecucion=None, medidas_faltantes=0):
    """
    Combina señales independientes en un puntaje 0-100 con intervalo.

      45%  autoevaluación del modelo (qué tan seguro dijo estar)
      20%  esquema: ¿las tablas que usa el SQL son las que el RAG trajo?
      15%  validación estructural (catálogo + advertencias)
      20%  ejecución: corrió, con filas, y trae cada medida pedida

    Antes la señal de esquema era SOLO la similitud TF-IDF pregunta↔ficha,
    que con preguntas de negocio («ventas en unidades y dólares por
    médico») contra columnas como `VentasUSD` da ~0.08: el RAG marcaba 25
    aunque hubiera encontrado exactamente las tablas correctas, y hundía un
    SQL bueno. Ahora vale lo mejor entre esa similitud y la cobertura real
    (fracción de tablas del SQL que estaban entre las recuperadas).

    La ejecución no se miraba: un SQL que tiraba error o que devolvía una
    sola de las dos medidas pedidas (unidades y moneda) salía con la misma
    confianza que uno perfecto.

    ejecucion: None (no se ejecutó), "ok", "vacio" o "error".
    """
    base_llm = conf_llm if conf_llm is not None else 60
    lexico = min(1.0, (sim_rag or 0) * 3.0)               # sim>0.33 satura
    senal_rag = max(lexico, cobertura if cobertura is not None else 0) * 100
    senal_val = (100 if es_valido else 20) - min(30, n_advertencias * 10)
    senal_ejec = {"ok": 100, "vacio": 55, "error": 0}.get(ejecucion, 60)
    senal_ejec = max(0, senal_ejec - 35 * medidas_faltantes)

    puntaje = (0.45 * base_llm + 0.20 * senal_rag
               + 0.15 * max(0, senal_val) + 0.20 * senal_ejec)
    if usa_cte:
        puntaje = min(100, puntaje + 2)   # estructura explícita: leve bonus
    if ejecucion == "error":
        puntaje = min(puntaje, 35)        # si no corrió, no puede ser alta

    margen = 4
    if conf_llm is None:
        margen += 7
    if senal_rag < 15:
        margen += 5
    if n_advertencias:
        margen += 3
    if ejecucion is None:
        margen += 4                       # sin correrla sabemos menos
    if medidas_faltantes:
        margen += 4

    puntaje = round(max(5, min(99, puntaje)))
    return {
        "puntaje": puntaje,
        "margen": margen,
        "intervalo": (max(0, puntaje - margen), min(100, puntaje + margen)),
        "componentes": {
            "modelo": round(base_llm),
            "rag": round(senal_rag),
            "validacion": round(max(0, senal_val)),
            "ejecucion": round(senal_ejec),
        },
    }


# Medidas que una pregunta puede pedir a la vez. «En unidades y en moneda»
# tiene que salir en DOS columnas: el modelo tendía a elegir una (o sumar
# unidades con dólares), y la pantalla no avisaba.
_MEDIDAS = {
    "unidades": (r"\bunidad(es)?\b|\bunits?\b|\bunidades\b|\bcantidad(es)?\b|"
                 r"\bquantity\b|\bquantidade\b|\bvolumen\b|\bvolume\b|\bpiezas\b"),
    "moneda": (r"\bmonto\b|\bimporte\b|\bmoneda\b|\bvalor(es)?\b|\bpesos\b|"
               r"\bd[oó]lar(es)?\b|\busd\b|\bu\$s\b|\bamount\b|\bcurrency\b|"
               r"\brevenue\b|\bfacturaci[oó]n\b|\bfaturamento\b|\breais\b|\$"),
}
_COL_MEDIDA = {
    "unidades": r"unid|units?|cant|qty|quant|volum|pieza",
    "moneda": r"usd|monto|importe|valor|value|amount|pesos|dolar|revenue|"
              r"factur|venta.*(usd|\$|monto)|\$|precio|price|moneda|reais",
}


def medidas_pedidas(pregunta):
    """Qué medidas pide la pregunta (sólo cuenta si pide más de una)."""
    q = (pregunta or "").lower()
    hay = [m for m, rx in _MEDIDAS.items() if re.search(rx, q)]
    return hay if len(hay) > 1 else []


def medidas_sin_columna(pedidas, columnas):
    """Medidas pedidas que no aparecen en ninguna columna del resultado."""
    cols = [str(c).lower() for c in (columnas or [])]
    return [m for m in pedidas
            if not any(re.search(_COL_MEDIDA[m], c) for c in cols)]


def _simple(nombre):
    return str(nombre).split(".")[-1].strip("[]\"`").lower()


def cobertura_esquema(sql, catalogo, recuperadas):
    """Fracción de las tablas del SQL que el RAG había recuperado.

    None si el SQL no nombra ninguna tabla del catálogo (no hay nada que
    medir: no se inventa una cobertura).
    """
    nombres = {_simple(t) for t in catalogo.get("tablas", {})}
    en_sql = {_simple(t) for t in re.findall(
        r"(?:from|join)\s+([\[\]\"`a-zA-Z_][\[\]\"`a-zA-Z0-9_.]*)", (sql or "").lower())}
    usadas = en_sql & nombres
    if not usadas:
        return None
    rec = {_simple(t) for t in recuperadas}
    return len(usadas & rec) / len(usadas)


# ──────────────────────────────────────────────────────────────
# 5) MOTOR COMPLETO
# ──────────────────────────────────────────────────────────────
class MotorMVSQL:
    """
    Motor principal. Recibe una ConexionBD ya conectada (conectores.py)
    y la configuración del proveedor de IA elegido por el cliente.
    """

    def __init__(self, conexion, ia):
        """
        conexion: ConexionBD conectada.
        ia: dict {proveedor, api_key, modelo, base_url}
        """
        self.cx = conexion
        self.ia = ia
        self.catalogo = conexion.extraer_catalogo()
        self.fichas = catalogo_a_fichas(self.catalogo)
        self.recuperador = RecuperadorEsquema(self.fichas)

    def _completar(self, system, user, max_tokens=1500):
        return completar(self.ia["proveedor"], self.ia.get("api_key"),
                         system, user, modelo=self.ia.get("modelo"),
                         base_url=self.ia.get("base_url"), max_tokens=max_tokens)

    def responder(self, pregunta, k=4, limite=5000, explicar=True, contexto="",
                  privado=False):
        """
        contexto: preferencias del usuario (moneda, decimales, etc.) que se
        pasan a la IA como instrucción adicional — no forman parte de la
        pregunta guardada ni del historial.
        privado: modo privacidad estricta. Con True, al proveedor de IA se le
        manda el esquema SIN valores de ejemplo de las columnas (texto_min) y
        no se genera análisis del resultado (explicar se fuerza a False): así
        NINGUN dato real de la base sale, ni al generar el SQL ni después.
        """
        if privado:
            explicar = False
        resultado = {
            "pregunta": pregunta, "tablas_recuperadas": [], "sql": None,
            "valido": False, "problemas": [], "advertencias": [],
            "confianza": None, "supuestos": "", "columnas": None, "filas": None,
            "sql_ejecutado": None, "error": None, "explicacion": None,
            "usa_cte": False,
        }

        # 1) RAG
        relevantes, sims = self.recuperador.recuperar(pregunta, k=k)
        resultado["tablas_recuperadas"] = [f["tabla"] for f in relevantes]
        sim_top = sims[0] if sims else 0.0

        # 2) generación. En modo privado se usa texto_min (sin valores de
        # ejemplo): al proveedor de IA solo van nombres de tablas y columnas.
        _clave = "texto_min" if privado else "texto"
        esquema = "\n\n".join(f.get(_clave, f["texto"]) for f in relevantes)
        _system_sql = """Sos un experto en SQL que traduce preguntas en lenguaje natural a consultas SQL de nivel profesional. La pregunta puede venir en español, inglés o portugués.

REGLAS ESTRICTAS:
1. Usá EXCLUSIVAMENTE las tablas y columnas del esquema provisto. NUNCA inventes nombres.
2. El motor es {dialecto}. Usá exactamente su sintaxis.
3. OPTIMIZACIÓN: si la consulta requiere agregaciones intermedias, subconsultas repetidas o pasos lógicos, estructurala con CTEs (WITH ... AS) con nombres descriptivos. Preferí CTE a subconsultas anidadas. Evitá SELECT *: listá solo las columnas necesarias. Filtrá lo antes posible (predicados en el WHERE más interno). Nunca apliques funciones sobre columnas indexables en el WHERE: usá rangos (col >= 'inicio' AND col < 'fin').
4. Si la pregunta pide ranking o "top", agregá ORDER BY y limitá filas.
5. Usá JOINs explícitos según las relaciones del esquema.
6. Filtrá registros anulados/eliminados si existe la columna (anulada=0, deleted=0, activo=1).
7. Solo SELECT (o WITH ... SELECT). Nunca INSERT/UPDATE/DELETE/DROP/ALTER/EXEC.
8. Alias legibles en español para columnas calculadas (total_cobrado, promedio_mensual).
9. Si la pregunta pide VARIAS medidas (por ejemplo unidades Y monto/moneda), devolvé UNA COLUMNA POR MEDIDA, separadas y con alias que las nombren (total_unidades, total_monto_usd). Nunca elijas una sola ni sumes unidades con dinero. Si el esquema tiene la medida en varias monedas, una columna por moneda.

FORMATO DE RESPUESTA — devolvé EXACTAMENTE esto, sin markdown ni explicación extra:
SQL:
<la consulta>
CONFIANZA: <entero 0-100: qué tan seguro estás de que la consulta responde exactamente la pregunta con este esquema>
SUPUESTOS: <si asumiste algo (interpretación de fechas, qué columna usar), listalo en una línea; si no, "ninguno">

ESQUEMA DISPONIBLE (usá solo esto):
{esquema}
"""
        system = _system_sql.format(dialecto=self.cx.dialecto, esquema=esquema)
        pregunta_ia = f"{pregunta}\n\n[Preferencias del usuario: {contexto}]" if contexto else pregunta
        crudo = self._completar(system, pregunta_ia)
        sql, conf_llm, supuestos = _parsear_respuesta_sql(crudo)
        resultado["sql"] = sql
        resultado["supuestos"] = supuestos
        resultado["usa_cte"] = sql.lower().lstrip().startswith("with")

        # 3) validación
        es_valido, problemas, advertencias = validar_sql(sql, self.catalogo)
        resultado["valido"] = es_valido
        resultado["problemas"] = problemas
        resultado["advertencias"] = advertencias

        # 3b) reintento automático si la validación falló (self-repair)
        if not es_valido:
            arreglado = self._reintentar_sql(system, pregunta_ia, sql, problemas)
            if arreglado:
                sql, conf_llm, supuestos, advertencias = arreglado
                es_valido, problemas = True, []
                resultado.update(sql=sql, supuestos=supuestos, valido=True,
                                 problemas=[], advertencias=advertencias,
                                 usa_cte=sql.lower().lstrip().startswith("with"))

        # 4) ejecución
        if es_valido:
            self._ejecutar_en(resultado, sql, limite)

        # 4b) ¿trae cada medida pedida? «unidades y moneda» son dos columnas.
        pedidas = medidas_pedidas(pregunta)
        faltan = (medidas_sin_columna(pedidas, resultado["columnas"])
                  if resultado["columnas"] is not None else [])
        if faltan:
            arreglado = self._reintentar_medidas(system, pregunta_ia, sql, faltan)
            if arreglado:
                sql2, conf2, sup2, adv2 = arreglado
                previo = dict(resultado)
                self._ejecutar_en(resultado, sql2, limite)
                faltan2 = medidas_sin_columna(pedidas, resultado["columnas"])
                if resultado["error"] is None and len(faltan2) < len(faltan):
                    sql, conf_llm, faltan = sql2, conf2, faltan2
                    resultado.update(sql=sql2, supuestos=sup2, advertencias=adv2,
                                     usa_cte=sql2.lower().lstrip().startswith("with"))
                else:
                    resultado.update({k: previo[k] for k in
                                      ("columnas", "filas", "sql_ejecutado", "error")})
        if faltan:
            resultado["advertencias"] = list(resultado["advertencias"]) + [
                "La pregunta pide " + " y ".join(pedidas) + ", pero el resultado "
                "no trae columna de: " + ", ".join(faltan) + "."]
        resultado["medidas_faltantes"] = faltan

        # 5) confianza, ya con lo que pasó al ejecutar
        if resultado["error"]:
            ejec = "error"
        elif resultado["filas"] is None:
            ejec = None
        else:
            ejec = "ok" if len(resultado["filas"]) else "vacio"
        resultado["confianza"] = calcular_confianza(
            conf_llm, sim_top, resultado["valido"], len(resultado["advertencias"]),
            resultado["usa_cte"],
            cobertura=cobertura_esquema(sql, self.catalogo,
                                        resultado["tablas_recuperadas"]),
            ejecucion=ejec, medidas_faltantes=len(faltan))

        # 6) explicación en lenguaje natural
        if explicar and resultado["filas"] is not None:
            resultado["explicacion"] = self._explicar_resultado(
                pregunta, sql, resultado, contexto)

        return resultado

    def _ejecutar_en(self, resultado, sql, limite):
        """Ejecuta (solo lectura) y deja columnas/filas/error en `resultado`."""
        resultado.update(columnas=None, filas=None, sql_ejecutado=None, error=None,
                         recorte=None)
        try:
            cols, filas, sql_exec = self.cx.ejecutar(sql, limite=limite)
            # Si un tope de rol recortó, el conector deja el total real:
            # viaja con el resultado para que la pantalla lo diga.
            resultado.update(columnas=cols, filas=filas, sql_ejecutado=sql_exec,
                             recorte=getattr(self.cx, "ultimo_recorte", None))
        except Exception as e:
            resultado["error"] = str(e)

    def _reintentar_medidas(self, system, pregunta_ia, sql, faltan):
        """Segunda vuelta cuando el SQL no trae todas las medidas pedidas.

        Devuelve (sql, confianza, supuestos, advertencias) si valida contra
        el catálogo, o None. Nunca se saltea la validación anti-alucinación.
        """
        pedido = (f"{pregunta_ia}\n\nTu consulta anterior fue:\n{sql}\n\n"
                  "No trae columna para: " + ", ".join(faltan) + ". La pregunta "
                  "pide esas medidas POR SEPARADO: devolvé una columna por cada "
                  "una, con alias que la nombre, usando SOLO el esquema.")
        try:
            sql2, conf2, sup2 = _parsear_respuesta_sql(self._completar(system, pedido))
            ok, _prob, adv = validar_sql(sql2, self.catalogo)
            if ok:
                return sql2, conf2, sup2, adv
        except Exception:
            pass
        return None

    def _reintentar_sql(self, system, pregunta_ia, sql, problemas):
        """Un intento de auto-corrección cuando el SQL no validó.

        Devuelve (sql, confianza, supuestos, advertencias) si la segunda
        vuelta sí valida, o None. Es best-effort: si el proveedor de IA
        falla, se sigue con el resultado original en vez de romper.
        """
        correccion = (f"{pregunta_ia}\n\nTu consulta anterior fue:\n{sql}\n\n"
                      f"Fue RECHAZADA por estos problemas:\n- " + "\n- ".join(problemas) +
                      "\nGenerá una consulta corregida usando SOLO tablas y columnas del esquema.")
        try:
            crudo = self._completar(system, correccion)
            sql2, conf2, supuestos2 = _parsear_respuesta_sql(crudo)
            ok, _prob, adv = validar_sql(sql2, self.catalogo)
            if ok:
                return sql2, conf2, supuestos2, adv
        except Exception:
            pass
        return None

    def _explicar_resultado(self, pregunta, sql, resultado, contexto):
        """Explicación en lenguaje natural de lo que dice el dato.

        Devuelve None si falla: la explicación es un extra, nunca puede
        tumbar una consulta que ya se ejecutó bien.
        """
        try:
            muestra = _muestra_texto(resultado["columnas"], resultado["filas"])
            extra = f"\n\nPREFERENCIAS DEL USUARIO: {contexto}" if contexto else ""
            _system_explicar = ("Sos un analista de datos. Te paso una pregunta de un "
                "usuario de negocio, el SQL ejecutado y una muestra del resultado. "
                "Explicá el resultado en 2-4 frases claras en el MISMO idioma de la "
                "pregunta, con números concretos. No expliques el SQL: explicá QUÉ dice "
                "el dato. Si el resultado está vacío, decilo y sugerí por qué puede ser.")
            return self._completar(
                _system_explicar,
                f"PREGUNTA: {pregunta}\n\nSQL:\n{sql}\n\nRESULTADO ({len(resultado['filas'])} filas):\n{muestra}{extra}",
                max_tokens=400)
        except Exception:
            return None

    def generar_stored_procedure(self, sql, nombre="sp_mvsql_consulta"):
        """Convierte una consulta guardada en stored procedure del dialecto activo."""
        _system_procedure = ("Sos un DBA experto. Convertí la consulta SELECT provista en un "
            "STORED PROCEDURE de nivel producción para {dialecto}, llamado {nombre}. "
            "Parametrizá las fechas y filtros literales que encuentres como parámetros con "
            "valores default sensatos. Incluí comentario de cabecera (propósito, parámetros, "
            "autor: MV SQL NLP). Devolvé SOLO el código SQL del procedure, sin markdown.")
        system = _system_procedure.format(dialecto=self.cx.dialecto, nombre=nombre)
        codigo = self._completar(system, sql, max_tokens=2000)
        return re.sub(r"```sql|```", "", codigo, flags=re.IGNORECASE).strip()

    def optimizar_sql(self, sql):
        """Reescribe una consulta existente optimizada con CTEs y buenas prácticas."""
        system = (f"Sos un optimizador de SQL para {self.cx.dialecto}. Reescribí la consulta "
                  "aplicando CTEs donde aporten claridad/performance, eliminando SELECT *, "
                  "y filtrando temprano. Mantené EXACTAMENTE la misma semántica. "
                  "Devolvé SOLO el SQL optimizado y después una línea 'CAMBIOS: ...' resumiendo qué mejoraste.")
        return self._completar(system, sql, max_tokens=2000)


def _muestra_texto(cols, filas, max_filas=20):
    lineas = [" | ".join(str(c) for c in cols)]
    for f in filas[:max_filas]:
        lineas.append(" | ".join(str(v) for v in f))
    if len(filas) > max_filas:
        lineas.append(f"... ({len(filas) - max_filas} filas más)")
    return "\n".join(lineas)
