"""
conector_mssql.py
==================================================================
Adaptador para usar el sistema NL2SQL contra SQL Server en produccion
(en vez de la demo SQLite).

Reemplaza las funciones de SQLite por equivalentes pyodbc. El resto del
sistema (RAG, validador, app) funciona igual: solo cambia de donde sale
el catalogo y donde se ejecuta el SQL.

Requisitos:
  pip install pyodbc
  ODBC Driver 17 (o 18) for SQL Server instalado en el sistema.

Uso en la app: importar estas funciones y pasarlas al MotorNL2SQL,
o adaptar MotorNL2SQL para recibir el dialecto "SQL Server".
==================================================================
"""

import pyodbc
from catalogo import extraer_catalogo_mssql, catalogo_a_fichas


def conectar(servidor, base, usuario, password, driver="ODBC Driver 17 for SQL Server",
             timeout=30):
    """
    Conexion robusta con manejo de error claro.
    Ejemplo:
        con = conectar("10.0.0.1", "MiBase", "usuario", "clave")
    """
    cadena = (
        f"DRIVER={{{driver}}};"
        f"SERVER={servidor};"
        f"DATABASE={base};"
        f"UID={usuario};"
        f"PWD={password};"
        f"TrustServerCertificate=yes;"
        f"Connection Timeout={timeout};"
    )
    try:
        con = pyodbc.connect(cadena, readonly=True)  # readonly por seguridad
        return con
    except pyodbc.Error as e:
        raise RuntimeError(f"No se pudo conectar a {servidor}/{base}: {e}")


def ejecutar_sql_mssql(sql, con, limite=5000):
    """
    Ejecuta un SELECT en SQL Server y devuelve (columnas, filas, sql_ejecutado).
    Agrega TOP N si la query no tiene TOP ni OFFSET.
    """
    sql_l = sql.lower()
    if "top " not in sql_l and "offset " not in sql_l:
        # insertar TOP despues del primer SELECT
        import re
        sql = re.sub(r"(?i)^\s*select\s+", f"SELECT TOP {limite} ", sql, count=1)

    cur = con.cursor()
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    filas = cur.fetchall()
    # pyodbc devuelve Row objects -> convertir a tuplas
    filas = [tuple(r) for r in filas]
    return cols, filas, sql


def cargar_catalogo_mssql(servidor, base, usuario, password, **kw):
    """Conecta, extrae el catalogo y devuelve (catalogo, fichas)."""
    con = conectar(servidor, base, usuario, password, **kw)
    catalogo = extraer_catalogo_mssql(con)
    fichas = catalogo_a_fichas(catalogo)
    con.close()
    return catalogo, fichas


# ──────────────────────────────────────────────────────────────
# Clase Motor para SQL Server (espejo de MotorNL2SQL pero con pyodbc)
# ──────────────────────────────────────────────────────────────
class MotorNL2SQL_MSSQL:
    def __init__(self, servidor, base, usuario, password, **kw):
        from motor_nl2sql import RecuperadorEsquema
        self.conn_kw = dict(servidor=servidor, base=base, usuario=usuario,
                            password=password, **kw)
        self.con = conectar(servidor, base, usuario, password, **kw)
        self.catalogo = extraer_catalogo_mssql(self.con)
        self.fichas = catalogo_a_fichas(self.catalogo)
        self.recuperador = RecuperadorEsquema(self.fichas)
        self.dialecto = "SQL Server (T-SQL)"

    def responder(self, pregunta, api_key=None, k=4):
        from motor_nl2sql import generar_sql_claude, validar_sql
        relevantes = self.recuperador.recuperar(pregunta, k=k)
        sql = generar_sql_claude(pregunta, relevantes, self.dialecto, api_key)
        es_valido, problemas = validar_sql(sql, self.catalogo)

        resultado = {
            "pregunta": pregunta,
            "tablas_recuperadas": [f["tabla"] for f in relevantes],
            "sql": sql, "valido": es_valido, "problemas": problemas,
            "columnas": None, "filas": None, "sql_ejecutado": None, "error": None,
        }
        if es_valido:
            try:
                cols, filas, sql_exec = ejecutar_sql_mssql(sql, self.con)
                resultado["columnas"] = cols
                resultado["filas"] = filas
                resultado["sql_ejecutado"] = sql_exec
            except Exception as e:
                resultado["error"] = str(e)
        return resultado


if __name__ == "__main__":
    print("Adaptador SQL Server. Ejemplo de uso:")
    print("""
    from conector_mssql import MotorNL2SQL_MSSQL
    motor = MotorNL2SQL_MSSQL("10.0.0.1", "MiBase", "usuario", "clave")
    r = motor.responder("cuanto cobramos en marzo 2026", api_key="sk-...")
    print(r["sql"])
    """)
