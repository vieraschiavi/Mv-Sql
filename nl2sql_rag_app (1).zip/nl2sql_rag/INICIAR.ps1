# ============================================================================
#  INICIAR.ps1 - Lanzador PowerShell del Asistente NL2SQL + RAG
#  Hace todo: detecta Python, crea venv, instala deps, genera DB, levanta app.
#  Como ejecutarlo:
#    Opcion A: click derecho -> "Ejecutar con PowerShell"
#    Opcion B: abrir PowerShell, ir a la carpeta, y correr:  .\INICIAR.ps1
#  Si da error de permisos, primero ejecutar (una vez):
#    Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
# ============================================================================

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   ASISTENTE NL2SQL + RAG" -ForegroundColor Cyan
Write-Host "   Carpeta: $PSScriptRoot" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# ---------- PASO 0: verificar archivos ----------
Write-Host "[0/5] Verificando archivos..." -ForegroundColor Yellow
$requeridos = @("app.py","motor_nl2sql.py","catalogo.py","generar_db_demo.py","requirements.txt")
$falta = $false
foreach ($f in $requeridos) {
    if (-not (Test-Path $f)) {
        Write-Host "      [ERROR] Falta: $f" -ForegroundColor Red
        $falta = $true
    }
}
if ($falta) {
    Write-Host ""
    Write-Host "  Faltan archivos. Pone INICIAR.ps1 en la MISMA carpeta que app.py" -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}
Write-Host "      [OK] Archivos presentes." -ForegroundColor Green

# ---------- PASO 1: detectar Python ----------
Write-Host "[1/5] Buscando Python..." -ForegroundColor Yellow
$pyexe = $null
# probar 'py'
try { & py -3 --version *> $null; if ($LASTEXITCODE -eq 0) { $pyexe = "py -3" } } catch {}
# probar 'python'
if (-not $pyexe) {
    try { & python --version *> $null; if ($LASTEXITCODE -eq 0) { $pyexe = "python" } } catch {}
}
# probar rutas comunes
if (-not $pyexe) {
    $rutas = @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe",
        "$env:ProgramFiles\Python313\python.exe",
        "$env:ProgramFiles\Python312\python.exe",
        "$env:ProgramFiles\Python311\python.exe",
        "C:\Anaconda3\python.exe",
        "$env:USERPROFILE\Anaconda3\python.exe",
        "$env:USERPROFILE\miniconda3\python.exe",
        "$env:USERPROFILE\AppData\Local\miniconda3\python.exe"
    )
    foreach ($r in $rutas) { if (Test-Path $r) { $pyexe = $r; break } }
}
if (-not $pyexe) {
    Write-Host "  [ERROR] No se encontro Python." -ForegroundColor Red
    Write-Host "  Instalalo desde https://www.python.org/downloads/ (marca 'Add to PATH')" -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}
Write-Host "      [OK] Python: $pyexe" -ForegroundColor Green

# helper para invocar python (maneja 'py -3' con espacio)
function Invoke-Py {
    param([string[]]$Args)
    if ($pyexe -eq "py -3") { & py -3 @Args }
    else { & $pyexe @Args }
}

# ---------- PASO 2: venv ----------
Write-Host "[2/5] Preparando entorno virtual..." -ForegroundColor Yellow
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "      Creando entorno virtual..."
    Invoke-Py @("-m","venv",".venv")
    Write-Host "      [OK] Creado." -ForegroundColor Green
} else {
    Write-Host "      [OK] Ya existe." -ForegroundColor Green
}
$venvPy = ".\.venv\Scripts\python.exe"

# ---------- PASO 3: dependencias ----------
Write-Host "[3/5] Verificando dependencias..." -ForegroundColor Yellow
if (-not (Test-Path ".venv\.deps_ok")) {
    Write-Host "      Instalando por primera vez (1-2 min)..."
    & $venvPy -m pip install --upgrade pip
    & $venvPy -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  [ERROR] Fallo la instalacion. Revisa internet." -ForegroundColor Red
        Read-Host "Presiona Enter para salir"
        exit 1
    }
    "ok" | Out-File ".venv\.deps_ok"
    Write-Host "      [OK] Instaladas." -ForegroundColor Green
} else {
    Write-Host "      [OK] Ya instaladas." -ForegroundColor Green
}

# ---------- PASO 4: base de datos ----------
Write-Host "[4/5] Verificando base de datos..." -ForegroundColor Yellow
if (-not (Test-Path "cartera_demo.db")) {
    Write-Host "      Generando base sintetica..."
    & $venvPy generar_db_demo.py
    Write-Host "      [OK] Generada." -ForegroundColor Green
} else {
    Write-Host "      [OK] Ya existe." -ForegroundColor Green
}

# ---------- PASO 5: streamlit ----------
Write-Host "[5/5] Iniciando aplicacion..." -ForegroundColor Yellow
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   La app abrira en el navegador en unos segundos." -ForegroundColor Cyan
Write-Host "   URL: http://localhost:8501" -ForegroundColor Cyan
Write-Host "   Para DETENER: Ctrl+C o cerra esta ventana." -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# abrir navegador en 7 segundos (en paralelo)
Start-Job -ScriptBlock { Start-Sleep 7; Start-Process "http://localhost:8501" } | Out-Null

& $venvPy -m streamlit run app.py --server.port 8501 --server.headless true

Write-Host ""
Write-Host "La aplicacion se detuvo." -ForegroundColor Yellow
Read-Host "Presiona Enter para salir"
