@echo off
REM ============================================================================
REM  DIAGNOSTICO.bat  —  Verifica el estado del entorno
REM ----------------------------------------------------------------------------
REM  Corre este BAT si algo no funciona. Reporta:
REM    - si Python esta instalado y su version
REM    - si el entorno virtual existe
REM    - si las dependencias estan instaladas
REM    - si la base de datos existe
REM    - si los archivos del proyecto estan completos
REM ============================================================================

setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title Diagnostico - Asistente NL2SQL
cd /d "%~dp0"

echo.
echo ============================================================
echo   DIAGNOSTICO DEL ENTORNO
echo ============================================================
echo.

REM --- 1. Python ---
echo [1] PYTHON
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE ( python --version >nul 2>&1 && set "PYEXE=python" )
if defined PYEXE (
    for /f "tokens=*" %%V in ('!PYEXE! --version 2^>^&1') do echo     [OK] %%V  ^(!PYEXE!^)
) else (
    echo     [FALTA] Python no encontrado en PATH ni en paths comunes.
    echo            Instalar desde https://www.python.org/downloads/
)
echo.

REM --- 2. Entorno virtual ---
echo [2] ENTORNO VIRTUAL (.venv)
if exist ".venv\Scripts\python.exe" (
    echo     [OK] Entorno virtual existe.
    for /f "tokens=*" %%V in ('.venv\Scripts\python.exe --version 2^>^&1') do echo          %%V
) else (
    echo     [FALTA] No existe. Ejecutar INSTALAR.bat
)
echo.

REM --- 3. Dependencias ---
echo [3] DEPENDENCIAS
if exist ".venv\Scripts\python.exe" (
    echo     Verificando paquetes clave...
    for %%M in (streamlit pandas plotly sklearn anthropic faker) do (
        .venv\Scripts\python.exe -c "import %%M" >nul 2>&1
        if !errorlevel! equ 0 (
            echo       [OK]    %%M
        ) else (
            echo       [FALTA] %%M  -^> ejecutar INSTALAR.bat
        )
    )
) else (
    echo     [SKIP] No hay entorno virtual.
)
echo.

REM --- 4. Base de datos ---
echo [4] BASE DE DATOS
if exist "cartera_demo.db" (
    echo     [OK] cartera_demo.db existe.
) else (
    echo     [FALTA] No existe. Se genera sola al correr INICIAR_APP.bat
)
echo.

REM --- 5. Archivos del proyecto ---
echo [5] ARCHIVOS DEL PROYECTO
for %%F in (app.py motor_nl2sql.py catalogo.py generar_db_demo.py requirements.txt) do (
    if exist "%%F" (
        echo     [OK]    %%F
    ) else (
        echo     [FALTA] %%F  -^> archivo del proyecto faltante!
    )
)
echo.

echo ============================================================
echo   FIN DEL DIAGNOSTICO
echo ============================================================
echo.
echo   Si todo dice [OK], ejecuta INICIAR_APP.bat
echo   Si algo dice [FALTA], segui la instruccion indicada.
echo.
pause
endlocal
