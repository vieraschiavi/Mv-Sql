"""
motor_nl2sql.py
==================================================================
Motor NL2SQL con RAG sobre el catalogo del esquema.

Flujo:
  pregunta (lenguaje natural)
    -> RAG: recuperar fichas de tablas relevantes (TF-IDF, sin API externa)
    -> LLM (Claude): genera SQL usando solo esas tablas/columnas
    -> Validador: chequea que cada tabla/columna exista en el catalogo
    -> Ejecucion segura (solo SELECT, LIMIT automatico)

El RAG de retrieval usa TF-IDF local (no manda nada afuera).
Solo la generacion final del SQL usa la API de Claude.
==================================================================
"""

import re
import sqlite3
import json
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from catalogo import (extraer_catalogo_sqlite, catalogo_a_fichas,
                      resumen_esquema_compacto)


# ──────────────────────────────────────────────────────────────
# 1) RETRIEVAL (RAG) — TF-IDF local sobre las fichas del esquema
# ──────────────────────────────────────────────────────────────
class RecuperadorEsquema:
    def __init__(self, fichas):
        self.fichas = fichas
        self.textos = [f["texto"] for f in fichas]
        # vectorizador en español, 1-2 gramas
        self.vec = TfidfVectorizer(lowercase=True, ngram_range=(1, 2),
                                   token_pattern=r"[a-zA-Záéíóúñ_]+")
        self.matriz = self.vec.fit_transform(self.textos)

    def recuperar(self, pregunta, k=4):
        q = self.vec.transform([pregunta])
        sims = cosine_similarity(q, self.matriz)[0]
        # devolver top-k tablas mas relevantes (siempre al menos 3 por seguridad)
        idx = sims.argsort()[::-1][:max(k, 3)]
        return [self.fichas[i] for i in idx]


# ──────────────────────────────────────────────────────────────
# 2) GENERACION SQL con Claude
# ──────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """Sos un experto en SQL que traduce preguntas en lenguaje natural (español) a consultas SQL.

REGLAS ESTRICTAS:
1. Usá EXCLUSIVAMENTE las tablas y columnas del esquema que te paso. NUNCA inventes nombres.
2. El motor es {dialecto}. Usá su sintaxis.
3. Devolvé SOLO la consulta SQL, sin explicaciones, sin markdown, sin ```sql.
4. Para fechas usá rangos (columna >= 'inicio' AND columna < 'fin'), nunca funciones sobre la columna en el WHERE.
5. Siempre filtrá filas anuladas si la columna existe (anulada = 0).
6. Si la pregunta pide un ranking o "top", agregá ORDER BY y LIMIT.
7. Usá JOINs explícitos según las relaciones del esquema.
8. Para montos usá SUM/AVG con los nombres exactos de columna.
9. Si la pregunta es ambigua, asumí la interpretación más común en cobranzas/cartera.
10. Nunca generes INSERT, UPDATE, DELETE, DROP, ALTER. Solo SELECT.

ESQUEMA DISPONIBLE (usá solo esto):
{esquema}
"""


def generar_sql_claude(pregunta, fichas_relevantes, dialecto="SQLite", api_key=None):
    """Llama a la API de Claude para generar el SQL."""
    try:
        import anthropic
    except ImportError:
        raise RuntimeError("Falta instalar 'anthropic': pip install anthropic")

    key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("Falta ANTHROPIC_API_KEY (variable de entorno o campo en la app)")

    esquema = "\n\n".join(f["texto"] for f in fichas_relevantes)
    system = SYSTEM_PROMPT.format(dialecto=dialecto, esquema=esquema)

    client = anthropic.Anthropic(api_key=key)
    resp = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        system=system,
        messages=[{"role": "user", "content": pregunta}],
    )
    sql = "".join(b.text for b in resp.content if hasattr(b, "text")).strip()
    # limpiar posibles backticks
    sql = re.sub(r"^```sql\s*|\s*```$", "", sql, flags=re.IGNORECASE | re.MULTILINE).strip()
    sql = re.sub(r"^```\s*|\s*```$", "", sql).strip()
    return sql


# ──────────────────────────────────────────────────────────────
# 3) VALIDADOR contra el catalogo (cero columnas inventadas)
# ──────────────────────────────────────────────────────────────
def validar_sql(sql, catalogo):
    """
    Verifica:
      - solo SELECT
      - todas las tablas referenciadas existen
      - (best-effort) columnas existen en alguna tabla del catalogo
    Devuelve (es_valido, lista_de_problemas)
    """
    problemas = []
    sql_lower = sql.lower()

    # 1) solo SELECT
    prohibidas = ["insert ", "update ", "delete ", "drop ", "alter ", "truncate ",
                  "create ", "exec ", "merge ", "grant ", "--", ";--"]
    for p in prohibidas:
        if p in sql_lower:
            problemas.append(f"Operacion no permitida detectada: '{p.strip()}'")
    if not sql_lower.lstrip().startswith("select") and "with" not in sql_lower[:10]:
        problemas.append("La consulta debe empezar con SELECT (o WITH).")

    # 2) tablas existentes
    tablas_catalogo = set(t.lower() for t in catalogo["tablas"].keys())
    # extraer tablas tras FROM y JOIN
    tablas_en_sql = set(re.findall(r"(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_]*)", sql_lower))
    for t in tablas_en_sql:
        if t not in tablas_catalogo:
            problemas.append(f"Tabla no existe en el catalogo: '{t}'")

    # 3) columnas (best-effort): todas las columnas conocidas
    columnas_catalogo = set()
    for info in catalogo["tablas"].values():
        for c in info["columnas"]:
            columnas_catalogo.add(c["columna"].lower())

    # extraer posibles columnas con prefijo alias.columna o columna sola
    posibles = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*\.([a-zA-Z_][a-zA-Z0-9_]*)", sql_lower)
    for col in set(posibles):
        if col not in columnas_catalogo and col not in ("*",):
            problemas.append(f"Posible columna inexistente: '{col}'")

    return (len([p for p in problemas if "no existe" in p or "no permitida" in p]) == 0, problemas)


# ──────────────────────────────────────────────────────────────
# 4) EJECUCION SEGURA
# ──────────────────────────────────────────────────────────────
def ejecutar_sql_sqlite(sql, db_path, limite=5000):
    """Ejecuta el SELECT y devuelve (columnas, filas). Agrega LIMIT si no tiene."""
    if "limit" not in sql.lower():
        sql = sql.rstrip("; \n") + f"\nLIMIT {limite}"
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    filas = cur.fetchall()
    con.close()
    return cols, filas, sql


# ──────────────────────────────────────────────────────────────
# 5) PIPELINE COMPLETO
# ──────────────────────────────────────────────────────────────
class MotorNL2SQL:
    def __init__(self, db_path, dialecto="SQLite"):
        self.db_path = db_path
        self.dialecto = dialecto
        self.catalogo = extraer_catalogo_sqlite(db_path)
        self.fichas = catalogo_a_fichas(self.catalogo)
        self.recuperador = RecuperadorEsquema(self.fichas)

    def responder(self, pregunta, api_key=None, k=4):
        # 1) RAG
        relevantes = self.recuperador.recuperar(pregunta, k=k)
        tablas_rel = [f["tabla"] for f in relevantes]

        # 2) generar SQL
        sql = generar_sql_claude(pregunta, relevantes, self.dialecto, api_key)

        # 3) validar
        es_valido, problemas = validar_sql(sql, self.catalogo)

        resultado = {
            "pregunta": pregunta,
            "tablas_recuperadas": tablas_rel,
            "sql": sql,
            "valido": es_valido,
            "problemas": problemas,
            "columnas": None, "filas": None, "sql_ejecutado": None, "error": None,
        }

        # 4) ejecutar si es valido
        if es_valido:
            try:
                cols, filas, sql_exec = ejecutar_sql_sqlite(sql, self.db_path)
                resultado["columnas"] = cols
                resultado["filas"] = filas
                resultado["sql_ejecutado"] = sql_exec
            except Exception as e:
                resultado["error"] = str(e)
        return resultado


if __name__ == "__main__":
    # prueba sin API (solo retrieval + validador con SQL escrito a mano)
    motor = MotorNL2SQL("cartera_demo.db")
    print("Catalogo cargado:", list(motor.catalogo["tablas"].keys()))

    # probar retrieval
    for preg in ["cuanto cobramos por mes en 2026",
                 "que clientes estan en juridica con mas deuda",
                 "contactabilidad por gestor"]:
        rel = motor.recuperador.recuperar(preg, k=3)
        print(f"\nPregunta: {preg}")
        print(f"  Tablas recuperadas: {[f['tabla'] for f in rel]}")

    # probar validador con SQL correcto e incorrecto
    print("\n--- VALIDADOR ---")
    sql_ok = "SELECT estado_id, COUNT(*) FROM clientes GROUP BY estado_id"
    sql_mal = "SELECT inventada FROM tabla_fantasma WHERE x=1"
    print("SQL correcto:", validar_sql(sql_ok, motor.catalogo))
    print("SQL inventado:", validar_sql(sql_mal, motor.catalogo))
