@echo off
REM ============================================================================
REM  INSTALAR.bat  —  Instalacion / reparacion del entorno
REM ----------------------------------------------------------------------------
REM  Usa este BAT solo si:
REM    - INICIAR_APP.bat falla en el paso de dependencias
REM    - queres forzar una reinstalacion limpia
REM    - actualizaste requirements.txt
REM
REM  Borra el entorno virtual y lo recrea desde cero.
REM ============================================================================

setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title Instalacion - Asistente NL2SQL
cd /d "%~dp0"

echo.
echo ============================================================
echo   INSTALACION / REPARACION DEL ENTORNO
echo ============================================================
echo.

REM --- Detectar Python ---
echo Buscando Python...
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE (
    python --version >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
    for %%P in (
        "%LocalAppData%\Programs\Python\Python312\python.exe"
        "%LocalAppData%\Programs\Python\Python311\python.exe"
        "%LocalAppData%\Programs\Python\Python310\python.exe"
        "C:\Anaconda3\python.exe"
        "%UserProfile%\Anaconda3\python.exe"
        "%UserProfile%\miniconda3\python.exe"
    ) do (
        if exist "%%~P" set "PYEXE=%%~P"
    )
)
if not defined PYEXE (
    echo [ERROR] No se encontro Python. Instalalo desde python.org
    pause
    exit /b 1
)
echo   Python: !PYEXE!
echo.

REM --- Borrar entorno viejo si existe ---
if exist ".venv" (
    echo Eliminando entorno virtual anterior...
    rmdir /s /q ".venv"
)

REM --- Crear entorno nuevo ---
echo Creando entorno virtual limpio...
!PYEXE! -m venv .venv
if !errorlevel! neq 0 (
    echo [ERROR] No se pudo crear el entorno virtual.
    pause
    exit /b 1
)

REM --- Instalar dependencias ---
echo Instalando dependencias...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if !errorlevel! neq 0 (
    echo.
    echo [ERROR] Fallo la instalacion. Revisa tu conexion a internet.
    pause
    exit /b 1
)

REM --- Marcar como instalado ---
echo ok > ".venv\.deps_ok"

echo.
echo ============================================================
echo   INSTALACION COMPLETA
echo   Ahora podes ejecutar INICIAR_APP.bat
echo ============================================================
echo.
pause
endlocal
