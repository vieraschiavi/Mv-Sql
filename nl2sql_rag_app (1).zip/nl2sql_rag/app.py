"""
app.py — Asistente NL2SQL con RAG
==================================================================
App Streamlit que responde preguntas en lenguaje natural sobre una
base de datos, devolviendo SQL + tabla + grafico automatico.

Arquitectura:
  - RAG local (TF-IDF) sobre el catalogo del esquema -> recupera tablas
  - Claude (API) genera el SQL usando solo esas tablas
  - Validacion contra catalogo -> cero columnas inventadas
  - Ejecucion segura (solo SELECT) -> tabla + grafico

Correr:
  pip install -r requirements.txt
  python generar_db_demo.py          # genera cartera_demo.db (una vez)
  streamlit run app.py
==================================================================
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import os

from motor_nl2sql import MotorNL2SQL, generar_sql_claude, validar_sql, ejecutar_sql_sqlite
from catalogo import catalogo_a_fichas

# ──────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────
st.set_page_config(page_title="Asistente NL2SQL", page_icon="🔎", layout="wide")

DB_DEMO = "cartera_demo.db"

# Estilo corporativo (azul oscuro + verde)
st.markdown("""
<style>
  .main { background-color: #f7f9fc; }
  h1, h2, h3 { color: #1e3a8a; }
  .stButton>button {
    background-color: #1e3a8a; color: white; border-radius: 8px;
    border: none; padding: 0.5rem 1.5rem; font-weight: 600;
  }
  .stButton>button:hover { background-color: #2748a8; }
  div[data-testid="stMetricValue"] { color: #1e3a8a; }
  .sql-box {
    background:#0f172a; color:#e2e8f0; padding:1rem; border-radius:8px;
    font-family:'Courier New',monospace; font-size:0.85rem; white-space:pre-wrap;
  }
</style>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────
# CARGA DEL MOTOR (cacheado)
# ──────────────────────────────────────────────────────────────
@st.cache_resource
def cargar_motor(db_path):
    return MotorNL2SQL(db_path)


# ──────────────────────────────────────────────────────────────
# GRAFICO AUTOMATICO segun tipos de columna
# ──────────────────────────────────────────────────────────────
def graficar_auto(df):
    """Elige el grafico mas adecuado segun la forma del DataFrame."""
    if df.empty or len(df) > 200:
        return None

    cols_num = df.select_dtypes(include="number").columns.tolist()
    cols_cat = [c for c in df.columns if c not in cols_num]
    cols_fecha = [c for c in df.columns
                  if "fecha" in c.lower() or "mes" in c.lower() or "periodo" in c.lower()
                  or "dia" in c.lower() or "anio" in c.lower() or "año" in c.lower()]

    try:
        # Serie temporal: fecha + numerica -> linea
        if cols_fecha and cols_num:
            x = cols_fecha[0]
            y = cols_num[0]
            df_s = df.sort_values(x)
            return px.line(df_s, x=x, y=y, markers=True,
                           color_discrete_sequence=["#1e3a8a"],
                           title=f"{y} por {x}")

        # Categoria + numerica -> barras
        if cols_cat and cols_num and len(df) <= 30:
            x = cols_cat[0]
            y = cols_num[0]
            df_b = df.sort_values(y, ascending=False)
            return px.bar(df_b, x=x, y=y,
                          color_discrete_sequence=["#1e3a8a"],
                          title=f"{y} por {x}")

        # 2 numericas -> scatter
        if len(cols_num) >= 2:
            return px.scatter(df, x=cols_num[0], y=cols_num[1],
                              color_discrete_sequence=["#8bc34a"],
                              title=f"{cols_num[1]} vs {cols_num[0]}")

        # 1 categoria con conteo -> pie (pocas categorias)
        if cols_cat and not cols_num and df[cols_cat[0]].nunique() <= 10:
            vc = df[cols_cat[0]].value_counts().reset_index()
            vc.columns = [cols_cat[0], "cantidad"]
            return px.pie(vc, names=cols_cat[0], values="cantidad")
    except Exception:
        return None
    return None


# ──────────────────────────────────────────────────────────────
# SIDEBAR
# ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Configuración")

    api_key = st.text_input("ANTHROPIC_API_KEY", type="password",
                            value=os.environ.get("ANTHROPIC_API_KEY", ""),
                            help="Tu API key de Anthropic. No se guarda.")

    st.divider()
    st.subheader("📁 Base de datos")
    db_path = st.text_input("Ruta SQLite", value=DB_DEMO)

    if not os.path.exists(db_path):
        st.error(f"No existe '{db_path}'. Corré primero: python generar_db_demo.py")
        st.stop()

    motor = cargar_motor(db_path)

    st.success(f"✓ {len(motor.catalogo['tablas'])} tablas cargadas")
    with st.expander("Ver esquema"):
        for t, info in motor.catalogo["tablas"].items():
            n = info.get("n_filas")
            st.markdown(f"**{t}** ({n:,} filas)" if n else f"**{t}**")
            cols = ", ".join(c["columna"] for c in info["columnas"])
            st.caption(cols)

    st.divider()
    k_tablas = st.slider("Tablas a recuperar (RAG)", 2, 6, 4,
                         help="Cuántas tablas del esquema se le pasan al LLM como contexto")


# ──────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────
st.title("🔎 Asistente de Consultas en Lenguaje Natural")
st.caption("Preguntá en español. El sistema recupera las tablas relevantes (RAG), "
           "genera el SQL con IA, lo valida contra el esquema y te muestra el resultado.")

# Ejemplos clicables
st.markdown("**Ejemplos:**")
ejemplos = [
    "¿Cuánto cobramos por mes en 2026?",
    "Top 10 clientes con más deuda en estado jurídico",
    "Contactabilidad por gestor (% de contactos exitosos)",
    "¿Cuántas operaciones por canal y su monto promedio?",
    "Arreglos de pago dados de baja por incumplimiento",
    "Distribución de clientes por estado",
]
cols_ej = st.columns(3)
pregunta_click = None
for i, ej in enumerate(ejemplos):
    if cols_ej[i % 3].button(ej, key=f"ej{i}", use_container_width=True):
        pregunta_click = ej

pregunta = st.text_input("Tu pregunta:", value=pregunta_click or "",
                         placeholder="Ej: ¿cuánto cobramos en marzo 2026 por departamento?")

col_btn, _ = st.columns([1, 4])
ejecutar = col_btn.button("▶️ Consultar", type="primary", use_container_width=True)

if (ejecutar or pregunta_click) and pregunta:
    if not api_key:
        st.error("Falta la API key de Anthropic en la barra lateral.")
        st.stop()

    with st.spinner("Recuperando tablas relevantes y generando SQL..."):
        try:
            resultado = motor.responder(pregunta, api_key=api_key, k=k_tablas)
        except Exception as e:
            st.error(f"Error: {e}")
            st.stop()

    # Tablas recuperadas por el RAG
    st.markdown("##### 🎯 Tablas recuperadas (RAG)")
    st.write(" · ".join(f"`{t}`" for t in resultado["tablas_recuperadas"]))

    # SQL generado
    st.markdown("##### 🧾 SQL generado")
    st.code(resultado["sql"], language="sql")

    # Validacion
    if resultado["valido"]:
        st.success("✓ SQL validado contra el catálogo (sin nombres inventados)")
    else:
        st.error("✗ La validación encontró problemas:")
        for p in resultado["problemas"]:
            st.write(f"  - {p}")

    if resultado["problemas"] and resultado["valido"]:
        with st.expander("⚠️ Advertencias menores"):
            for p in resultado["problemas"]:
                st.write(f"  - {p}")

    # Error de ejecucion
    if resultado["error"]:
        st.error(f"Error al ejecutar: {resultado['error']}")

    # Resultados
    if resultado["columnas"] and resultado["filas"] is not None:
        df = pd.DataFrame(resultado["filas"], columns=resultado["columnas"])

        # intentar convertir columnas de fecha
        for c in df.columns:
            if "fecha" in c.lower():
                df[c] = pd.to_datetime(df[c], errors="ignore")

        st.markdown("##### 📊 Resultado")

        c1, c2, c3 = st.columns(3)
        c1.metric("Filas", f"{len(df):,}")
        c2.metric("Columnas", len(df.columns))
        cols_num = df.select_dtypes(include="number").columns.tolist()
        if cols_num:
            c3.metric(f"Σ {cols_num[0]}", f"{df[cols_num[0]].sum():,.0f}")

        tab1, tab2 = st.tabs(["📋 Tabla", "📈 Gráfico"])
        with tab1:
            st.dataframe(df, use_container_width=True, height=400)
            csv = df.to_csv(index=False).encode("utf-8")
            st.download_button("⬇️ Descargar CSV", csv,
                               file_name="resultado.csv", mime="text/csv")
        with tab2:
            fig = graficar_auto(df)
            if fig:
                fig.update_layout(plot_bgcolor="white", paper_bgcolor="white",
                                  font_color="#1e3a8a")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No se pudo generar un gráfico automático para esta forma de datos "
                        "(demasiadas filas o tipos no graficables).")

st.divider()
st.caption("RAG local (TF-IDF) + Claude API · Validación contra catálogo · Solo lectura (SELECT). "
           "Datos sintéticos generados para demostración.")
