@echo off
REM ============================================================================
REM  INICIAR_APP.bat  (version BLINDADA v2 - sin auto-relanzamiento)
REM  - Cada salida de error pasa por :fin que tiene PAUSE -> nunca cierra solo
REM  - Guarda todo en _log_inicio.txt
REM  - Verifica carpeta correcta antes de empezar
REM  Para mas seguridad: abri CMD y arrastra este .bat adentro.
REM ============================================================================
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title Asistente NL2SQL + RAG
cd /d "%~dp0"

set "LOG=_log_inicio.txt"
echo LOG DE INICIO - %DATE% %TIME% > "%LOG%"
echo Carpeta: %CD% >> "%LOG%"

echo.
echo ============================================================
echo   ASISTENTE NL2SQL + RAG
echo   Carpeta: %CD%
echo ============================================================
echo.

REM ---------- PASO 0: Verificar archivos ----------
echo [0/5] Verificando archivos del proyecto...
set "FALTA="
for %%F in (app.py motor_nl2sql.py catalogo.py generar_db_demo.py requirements.txt) do (
    if not exist "%%F" (
        echo       [ERROR] Falta: %%F
        echo FALTA: %%F >> "%LOG%"
        set "FALTA=1"
    )
)
if defined FALTA (
    echo.
    echo  [ERROR] Faltan archivos del proyecto en esta carpeta.
    echo  CAUSA: moviste el .bat sin los archivos .py
    echo  SOLUCION: pone INICIAR_APP.bat junto a app.py y los demas .py
    goto :fin
)
echo       [OK] Archivos presentes.
echo.

REM ---------- PASO 1: Detectar Python ----------
echo [1/5] Buscando Python...
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE ( python --version >nul 2>&1 && set "PYEXE=python" )
if not defined PYEXE (
    for %%P in (
        "%LocalAppData%\Programs\Python\Python313\python.exe"
        "%LocalAppData%\Programs\Python\Python312\python.exe"
        "%LocalAppData%\Programs\Python\Python311\python.exe"
        "%LocalAppData%\Programs\Python\Python310\python.exe"
        "%ProgramFiles%\Python313\python.exe"
        "%ProgramFiles%\Python312\python.exe"
        "%ProgramFiles%\Python311\python.exe"
        "C:\Python312\python.exe"
        "C:\Python311\python.exe"
        "C:\Anaconda3\python.exe"
        "%UserProfile%\Anaconda3\python.exe"
        "%UserProfile%\miniconda3\python.exe"
        "%UserProfile%\AppData\Local\miniconda3\python.exe"
    ) do (
        if exist "%%~P" set "PYEXE=%%~P"
    )
)
if not defined PYEXE (
    echo.
    echo  [ERROR] No se encontro Python.
    echo  Instalalo desde https://www.python.org/downloads/
    echo  IMPORTANTE: marca "Add Python to PATH" al instalar.
    echo ERROR: Python no encontrado >> "%LOG%"
    goto :fin
)
echo       [OK] Python: !PYEXE!
echo OK Python: !PYEXE! >> "%LOG%"
echo.

REM ---------- PASO 2: Entorno virtual ----------
echo [2/5] Preparando entorno virtual...
if not exist ".venv\Scripts\python.exe" (
    echo       Creando entorno virtual...
    !PYEXE! -m venv .venv >> "%LOG%" 2>&1
    if !errorlevel! neq 0 (
        echo  [ERROR] No se pudo crear el entorno virtual. Ver %LOG%
        goto :fin
    )
    echo       [OK] Creado.
) else (
    echo       [OK] Ya existe.
)
set "VENV_PY=.venv\Scripts\python.exe"
echo.

REM ---------- PASO 3: Dependencias ----------
echo [3/5] Verificando dependencias...
if not exist ".venv\.deps_ok" (
    echo       Instalando por primera vez ^(1-2 minutos^)...
    "%VENV_PY%" -m pip install --upgrade pip >> "%LOG%" 2>&1
    "%VENV_PY%" -m pip install -r requirements.txt >> "%LOG%" 2>&1
    if !errorlevel! neq 0 (
        echo  [ERROR] Fallo la instalacion. Revisa internet. Ver %LOG%
        goto :fin
    )
    echo ok > ".venv\.deps_ok"
    echo       [OK] Instaladas.
) else (
    echo       [OK] Ya instaladas.
)
echo.

REM ---------- PASO 4: Base de datos ----------
echo [4/5] Verificando base de datos...
if not exist "cartera_demo.db" (
    echo       Generando base sintetica...
    "%VENV_PY%" generar_db_demo.py >> "%LOG%" 2>&1
    if !errorlevel! neq 0 (
        echo  [ERROR] Fallo la generacion. Ver %LOG%
        goto :fin
    )
    echo       [OK] Generada.
) else (
    echo       [OK] Ya existe.
)
echo.

REM ---------- PASO 5: Streamlit ----------
echo [5/5] Iniciando aplicacion...
echo.
echo ============================================================
echo   La app abrira en el navegador en unos segundos.
echo   URL: http://localhost:8501
echo   Para DETENER: Ctrl+C o cerra esta ventana.
echo ============================================================
echo.
start "" /b cmd /c "timeout /t 7 >nul & start http://localhost:8501"
"%VENV_PY%" -m streamlit run app.py --server.port 8501 --server.headless true
echo.
echo La aplicacion se detuvo.

:fin
echo.
echo ============================================================
echo   Proceso finalizado. Revisa los mensajes de arriba.
echo ============================================================
echo.
pause
endlocal
