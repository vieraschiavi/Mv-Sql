# 🔎 Asistente NL2SQL con RAG

Sistema que responde **preguntas en lenguaje natural** (español) sobre cualquier base de datos relacional, devolviendo **SQL validado + tabla + gráfico automático**.

Construido sobre la idea del extractor de catálogo: en vez de conectarse a ciegas, el sistema **extrae el esquema completo de la base una vez**, lo indexa con RAG, y usa ese catálogo como fuente de verdad para que el LLM nunca invente nombres de tablas o columnas.

---

## 🧠 Cómo funciona (arquitectura)

```
   Pregunta en español
   "¿cuánto cobramos por mes en 2026?"
              │
              ▼
   ┌──────────────────────────────┐
   │ 1. RAG (TF-IDF local)        │   Recupera las tablas del esquema más
   │    sobre el catálogo          │   relevantes a la pregunta. NO sale nada
   │                               │   de tu red — el retrieval es local.
   └──────────────────────────────┘
              │  tablas: cuotas, operaciones
              ▼
   ┌──────────────────────────────┐
   │ 2. Claude (API)              │   Genera el SQL usando SOLO las tablas/
   │    genera el SQL              │   columnas recuperadas. Recibe el esquema
   │                               │   como contexto, no los datos.
   └──────────────────────────────┘
              │  SELECT strftime(...) FROM cuotas ...
              ▼
   ┌──────────────────────────────┐
   │ 3. Validador                 │   Chequea contra el catálogo: ¿existe cada
   │    contra el catálogo         │   tabla? ¿cada columna? ¿es solo SELECT?
   │                               │   Bloquea INSERT/UPDATE/DELETE/DROP.
   └──────────────────────────────┘
              │  ✓ válido
              ▼
   ┌──────────────────────────────┐
   │ 4. Ejecución segura          │   Corre el SELECT (con LIMIT/TOP automático)
   │    + visualización            │   → tabla + gráfico elegido según los tipos
   │                               │   de columna (línea/barras/scatter/pie).
   └──────────────────────────────┘
```

**Por qué este diseño es seguro para entornos corporativos:**
- El **retrieval (RAG) es 100% local** — usa TF-IDF, nada se manda afuera.
- A la API de Claude solo va **el esquema** (nombres de tablas/columnas), nunca los datos.
- La conexión a la base es **read-only** y el validador **solo permite SELECT**.
- El catálogo queda **versionado y auditable** (como el flujo offline del skill de indexación).

---

## 📦 Archivos

| Archivo | Qué hace |
|---------|----------|
| **`INICIAR_APP.bat`** | **Autorun all-in-one (Windows): corre todo con un click** |
| `INSTALAR.bat` | Reinstalación limpia del entorno (Windows) |
| `DIAGNOSTICO.bat` | Verifica el entorno y reporta problemas (Windows) |
| `app.py` | App Streamlit (la interfaz principal) |
| `motor_nl2sql.py` | Motor: RAG + generación SQL + validador + ejecución (SQLite) |
| `catalogo.py` | Extracción del catálogo del esquema (SQLite y SQL Server) |
| `conector_mssql.py` | Adaptador para apuntar a **SQL Server** en producción |
| `generar_db_demo.py` | Genera la base sintética de cartera/cobranzas para probar |
| `requirements.txt` | Dependencias |

---

## 🚀 Inicio rápido (Windows — un solo click)

**La forma más fácil: doble click en `INICIAR_APP.bat`**

Ese único archivo hace TODO automáticamente, sin bugs:
1. Detecta Python (prueba `py`, `python` y rutas comunes de instalación / Anaconda)
2. Crea un entorno virtual aislado (`.venv`)
3. Instala las dependencias (solo la primera vez)
4. Genera la base de datos sintética (solo si no existe)
5. Levanta la app y abre el navegador en `http://localhost:8501`

Si algo falla, se detiene mostrando el error (no se cierra solo). Para detener la app, cerrá la ventana o `Ctrl+C`.

### BATs auxiliares (Windows)

| BAT | Cuándo usarlo |
|-----|---------------|
| **`INICIAR_APP.bat`** | El de siempre — corre todo y levanta la app |
| **`DIAGNOSTICO.bat`** | Si algo no anda: verifica Python, venv, dependencias, DB y archivos |
| **`INSTALAR.bat`** | Para forzar una reinstalación limpia (borra y recrea el `.venv`) |

> Lo único que tenés que hacer manualmente es pegar tu **`ANTHROPIC_API_KEY`** en la barra lateral de la app.

---

## 🐧 Instalación manual (Linux / Mac / o si preferís control total)

```bash
# 1. Instalar dependencias
pip install -r requirements.txt

# 2. Generar la base de datos sintética de demostración (una vez)
python generar_db_demo.py
#    → crea cartera_demo.db (2000 clientes, ~5000 operaciones, ~97k cuotas)

# 3. Levantar la app
streamlit run app.py

# 4. En la barra lateral, pegá tu ANTHROPIC_API_KEY y empezá a preguntar.
```

La app abre en `http://localhost:8501`.

---

## 💬 Ejemplos de preguntas (incluidos como botones)

- *¿Cuánto cobramos por mes en 2026?* → serie temporal en línea
- *Top 10 clientes con más deuda en estado jurídico* → tabla ordenada
- *Contactabilidad por gestor (% de contactos exitosos)* → barras
- *¿Cuántas operaciones por canal y su monto promedio?* → barras
- *Arreglos de pago dados de baja por incumplimiento* → tabla
- *Distribución de clientes por estado* → barras / pie

---

## 🏢 Apuntar a producción (SQL Server)

La demo usa SQLite, pero el sistema funciona igual contra SQL Server. Dos opciones:

### Opción A — extraer el catálogo offline (recomendado si no hay conexión directa)

1. Ejecutá `EXTRAER_METADATA_BD_COMPLETA.sql` en SSMS → exportá a Excel.
2. Adaptá `catalogo.py` para leer ese Excel en vez de la base.
3. El RAG y la generación de SQL funcionan sin tocar la base; solo ejecutás el SQL final manualmente o con permiso de lectura.

### Opción B — conexión directa read-only

```python
from conector_mssql import MotorNL2SQL_MSSQL

motor = MotorNL2SQL_MSSQL(
    servidor="10.0.0.1",
    base="MiBase",
    usuario="usuario_lectura",
    password="••••••",
)
resultado = motor.responder("cuánto cobramos en marzo 2026", api_key="sk-ant-...")
print(resultado["sql"])
```

Requiere `pip install pyodbc` y el **ODBC Driver 17/18 for SQL Server**.

Para usar la app Streamlit con SQL Server, reemplazá en `app.py` la línea
`motor = cargar_motor(db_path)` por una instancia de `MotorNL2SQL_MSSQL`
con los datos de conexión en la barra lateral.

---

## 🔧 Personalización

- **Más tablas al LLM**: subí el slider "Tablas a recuperar (RAG)" en la barra lateral.
- **Reglas de negocio**: editá el `SYSTEM_PROMPT` en `motor_nl2sql.py` (ej: filtros obligatorios, definiciones de métricas, fórmulas de cobrado).
- **Otro modelo**: cambiá `model="claude-sonnet-4-6"` en `generar_sql_claude()`.
- **Gráficos**: la lógica de selección automática está en `graficar_auto()` en `app.py`.

---

## 🔒 Seguridad

- Solo se permiten consultas `SELECT` / `WITH`. El validador bloquea cualquier DML/DDL.
- La conexión a SQL Server se abre en modo `readonly=True`.
- Se aplica `LIMIT`/`TOP` automático para evitar traer millones de filas.
- La API key no se persiste — se ingresa en cada sesión.
- A la API solo viaja el **esquema**, nunca los datos de las filas.

---

## 📊 Validación del pipeline

Probado end-to-end con la base sintética. Ejemplo de resultados reales:

| Pregunta | Tablas recuperadas (RAG) | Resultado |
|----------|--------------------------|-----------|
| Cobrado por mes 2026 | cuotas, operaciones | 6 meses, ~$20M/mes |
| Top deuda jurídica | clientes, estados, cuotas, operaciones | 10 clientes |
| Contactabilidad por gestor | gestiones | 15 gestores, ~40% |
| Clientes por estado | clientes, estados | 6 subestados |

---

*RAG local (TF-IDF) + Claude API · Validación contra catálogo · Solo lectura · Datos sintéticos de demostración.*
